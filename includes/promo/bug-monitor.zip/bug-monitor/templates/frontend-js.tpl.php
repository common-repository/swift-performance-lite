<script>bug_monitor = <?php echo json_encode(array(
                  'event_endpoint' => rest_url('bug-monitor/v1/report/event'),
                  'session_endpoint' => rest_url('bug-monitor/v1/report/session'),
                  'mutation_endpoint' => rest_url('bug-monitor/v1/report/mutations'),
                  'screenshot_endpoint' => rest_url('bug-monitor/v1/report/screenshot'),
                  'single_event_endpoint' => rest_url('bug-monitor/v1/report/single_event'),
                  'html2canvas_src' => BUG_MONITOR_PLUGIN_URL . 'assets/html2canvas.min.js',
                  'errors' => array(),
                  'ajax' => array(),
                  'csp' => array(),
                  'is404' => is_404(),
                  'config' => array_combine(Bug_Monitor_Config::$triggers, array_map(function($key) {
                        return Bug_Monitor::get_option($key);
                  }, Bug_Monitor_Config::$triggers))
      ));
      ?>;

      <?php if (function_exists('is_checkout') && function_exists('WC') && is_checkout()):?>
            bug_monitor.revenue = '<?php echo strip_tags(WC()->cart->get_total())?>';
      <?php endif;?>

      <?php include BUG_MONITOR_PLUGIN_DIR . 'assets/head.js'?>
</script>