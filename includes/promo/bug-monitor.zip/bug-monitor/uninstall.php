<?php

if (!defined('WP_UNINSTALL_PLUGIN')) {
    die;
}

if (!current_user_can('activate_plugins')){
      return;
}

include_once __DIR__ . '/main.php';
Bug_Monitor::uninstall();

?>