<div class="notice notice-error is-dismissible bug-monitor-notice" data-id="<?php echo esc_attr($data['id']);?>" data-nonce="<?php echo wp_create_nonce('bug-monitor-ajax');?>" style="border-left-color: #4623c9;">
      <p>
      <strong><?php esc_html_e('BugMonitor notice')?></strong><br><br>
      <?php
            // Already escaped
            echo $data['message'];
      ?>
      </p>
</div>