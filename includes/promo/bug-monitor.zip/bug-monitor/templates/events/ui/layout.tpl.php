<?php if($data['details']['issue'] == 'body-overflow'):?>
      <strong><?php esc_html_e('Body overflow issue', 'bug-monitor');?></strong><br><br>
      <?php esc_html_e('An element on the page is causing the body to exceed the screen width, leading to an overflow issue. This could create a poor user experience as it may require horizontal scrolling on devices with smaller screens.', 'bug-monitor');?>
<?php elseif($data['details']['issue'] == 'text-overflow'):?>
      <strong><?php esc_html_e('Text overflow issue', 'bug-monitor');?></strong><br><br>
      <?php esc_html_e('Text on the page is exceeding the boundaries of its parent element, leading to overflow. This issue can make the content unreadable and disrupt the layout of the page, impacting the user experience negatively.', 'bug-monitor');?>
<?php elseif($data['details']['issue'] == 'ugly-break'):?>
      <strong><?php esc_html_e('Unnatural word break', 'bug-monitor');?></strong><br><br>
      <?php esc_html_e('Certain words on the page are breaking awkwardly due to insufficient space within their container. This results in a poor visual presentation, making the text hard to read and negatively affecting the overall user experience, especially on smaller screens.', 'bug-monitor');?>
<?php elseif($data['details']['insufficient-padding'] == 'text-overflow'):?>
      <strong><?php esc_html_e('Insufficient padding', 'bug-monitor');?></strong><br><br>
      <?php esc_html_e('A child element is situated too near the borders of its parent element, resulting in a cluttered look. This closeness can detract from the overall design\'s visual appeal and readability, negatively affecting the user experience by making the content appear overcrowded and less navigable.', 'bug-monitor');?>
<?php endif;?>
