<table width="100%" border="0" cellspacing="0" cellpadding="0" align="center" style="margin: 30px auto;padding-bottom: 30px;border-bottom:1px solid #ececec;">
  <tr>
      <td align="center" valign="middle" style="text-align: center; vertical-align: middle;width:100px">
            <table class="bug-monitor-event-icon bm-<?php echo esc_attr($data['level']);?>" style="text-align: center; width:80px; border-radius:15px;">
                  <tr valign="middle">
                        <td><img src="<?php echo BUG_MONITOR_SITE_URL;?>images/email/<?php echo $data['category'];?>.png"></td>
                  </tr>
            </table>
            <table style="text-align: center; width:80px">
                  <tr>
                        <td>
                              <div style="font-weight: 600;"><?php echo Bug_Monitor_Dashboard::get_category($data['category']);?> <?php echo Bug_Monitor_Dashboard::get_level($data['level']);?></div>
                        </td>
                  </tr>
            </table>
      </td>
      <td valign="top">
            <div style="font-weight:600;">
                  <?php echo Bug_Monitor_Dashboard::get_title($data['type'])?><br>
                  <?php if (!empty($data['details']['revenue'])):?>
                        <span style="font-size: 0.8em;color: #e94552;font-weight: 400;"><?php echo sprintf(esc_html__('Possible revenue loss: %s', 'bug-monitor'), $data['details']['revenue'])?></span>
                  <?php endif;?><br>
                  <span style="font-size:12px;color:#888;font-weight:400;">
                        <?php echo Bug_Monitor_Dashboard::get_timestamps($data)?>
                        (<?php echo esc_html(sprintf(_n('one event', '%d events', $data['count'], 'bug-monitor'), $data['count']));?>)
                  </span>
            </div>
            <p style="font-size:.9em;"><?php echo Bug_Monitor_Dashboard::get_description($data)?></p>
            <div class="buttons">
                  <?php if (!empty($data['visual_type'])):?>
                  <a href="<?php echo add_query_arg(array('event_hash' => $data['event_hash']), Bug_Monitor_Helper::get_dashbord_url());?>" class="btn" target="_blank">
                        <?php if ($data['visual_type'] == 'video'):?>
                              <img src="<?php echo BUG_MONITOR_SITE_URL;?>images/email/video.png">
                              <?php esc_html_e('View video', 'bug-monitor');?>
                        <?php elseif ($data['visual_type'] == 'email'):?>
                              <img src="<?php echo BUG_MONITOR_SITE_URL;?>/images/email/email.png">
                              <?php esc_html_e('View email', 'bug-monitor');?>
                        <?php else:?>
                              <img src="<?php echo BUG_MONITOR_SITE_URL;?>images/email/image.png">
                              <?php esc_html_e('View Screenshot', 'bug-monitor');?>
                        <?php endif;?>
                  </a><br><br>
                  <?php elseif(in_array($data['type'], array_merge(Bug_Monitor_Log::$record_types, Bug_Monitor_Log::$screenshot_types)) && !empty($data['preview_link'])):?>
                        <a href="<?php echo add_query_arg(array('event_hash' => $data['event_hash']), Bug_Monitor_Helper::get_dashbord_url());?>" target="_blank" class="btn">
                              <img src="<?php echo BUG_MONITOR_SITE_URL;?>/images/email/link-preview.png">
                              <?php esc_html_e('Live Preview', 'bug-monitor');?>
                        </a>
                  <?php endif;?>
                  <a href="<?php echo add_query_arg(array('event_hash' => $data['event_hash']), Bug_Monitor_Helper::get_dashbord_url());?>" class="btn" target="_blank"><?php esc_html_e('See Details', 'bug-monitor');?></a>
            </div>
      </td>
  </tr>
</table>