<?php echo Bug_Monitor_Dashboard::get_description($data);?>
<p>
      <strong><?php esc_html_e('Proper alt attribute is crucial for:', 'bug-monitor');?></strong>
      <ol>
            <li><?php esc_html_e('Accessibility: It provides a textual description of images for visually impaired users using screen readers.', 'bug-monitor');?></li>
            <li><?php esc_html_e('Search Engine Optimization: Helps search engines understand and index the image content, improving website visibility.', 'bug-monitor');?></li>
            <li><?php esc_html_e('In Case of Loading Issues: Displays alternative text when images fail to load, maintaining user understanding of the content.', 'bug-monitor');?></li>
      </ol>
</p>