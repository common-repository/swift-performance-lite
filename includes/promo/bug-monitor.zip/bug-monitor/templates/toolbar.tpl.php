<?php $log_count = Bug_Monitor_Log::get_log_count(array('status' => array(1,2)));?>
<span style="display:flex;align-items:center;gap:5px;height:100%;"><img src="<?php echo BUG_MONITOR_PLUGIN_URL?>images/icon.png" style="width:20px;height:20px">
      <?php if ($log_count > 0):?>
            <?php echo $log_count;?>
      <?php endif;?>
</span>